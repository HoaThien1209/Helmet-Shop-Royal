// ===== CART STATE (localStorage) =====
const CART_KEY = "mubaohiem_cart_v1";

function loadCart() {
  try {
    const raw = localStorage.getItem(CART_KEY);
    const arr = JSON.parse(raw || "[]");
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function saveCart(cart) {
  localStorage.setItem(CART_KEY, JSON.stringify(cart || []));
}

let cart = loadCart();

// ===== HELPERS =====
function formatVND(v) {
  return Number(v || 0).toLocaleString("vi-VN") + "₫";
}

// Expose for cart page
function getCart() { return cart; }

function updateCartBadge() {
  const badge = document.getElementById("cartBadge");
  if (!badge) return;

  const count = cart.reduce((sum, i) => sum + Number(i.qty || 0), 0);
  badge.textContent = String(count);

  if (count > 0) badge.classList.remove("hidden");
  else badge.classList.add("hidden");
}

// ===== MINI RENDER (optional: only if element exists) =====
function renderCart() {
  const cartItemsEl = document.getElementById("cartItems");
  const cartTotalEl = document.getElementById("cartTotal");

  // Nếu trang không có cột giỏ (index mới) thì không render
  if (!cartItemsEl || !cartTotalEl) {
    updateCartBadge();
    return;
  }

  if (!cart.length) {
    cartItemsEl.innerHTML = '<div class="italic text-slate-400">Chưa có sản phẩm nào.</div>';
    cartTotalEl.textContent = "0₫";
    updateCartBadge();
    return;
  }

  let total = 0;
  cartItemsEl.innerHTML = "";
  cart.forEach(item => {
    total += Number(item.price || 0) * Number(item.qty || 0);

    const row = document.createElement("div");
    row.className = "flex justify-between items-start gap-2";
    row.innerHTML = `
      <div class="min-w-0">
        <div class="truncate">${item.name}</div>
        <div class="text-[11px] text-slate-400">
          ${item.qty} x ${formatVND(item.price)}
        </div>
      </div>
      <button class="text-red-300 text-xs" onclick="removeFromCart(${item.id})">x</button>
    `;
    cartItemsEl.appendChild(row);
  });

  cartTotalEl.textContent = formatVND(total);
  updateCartBadge();
}

// ===== CART ACTIONS =====
function addToCart(product) {
  const pid = Number(product.id);
  const existing = cart.find(i => Number(i.id) === pid);

  if (existing) existing.qty += 1;
  else cart.push({ id: pid, name: product.name, price: Number(product.price || 0), qty: 1 });

  saveCart(cart);
  renderCart();
  updateCartBadge();
}

function removeFromCart(id) {
  cart = cart.filter(i => Number(i.id) !== Number(id));
  saveCart(cart);
  renderCart();
  updateCartBadge();
}

function incQty(id) {
  const item = cart.find(i => Number(i.id) === Number(id));
  if (!item) return;
  item.qty += 1;
  saveCart(cart);
}

function decQty(id) {
  const item = cart.find(i => Number(i.id) === Number(id));
  if (!item) return;
  item.qty -= 1;
  if (item.qty <= 0) cart = cart.filter(i => Number(i.id) !== Number(id));
  saveCart(cart);
}

function clearCart() {
  cart = [];
  saveCart(cart);
}

// ===== CHECKOUT =====
async function submitOrder(e) {
  e.preventDefault();
  if (!cart.length) {
    alert("Giỏ hàng đang trống.");
    return;
  }

  const form = e.target;
  const data = {
    name: form.name.value.trim(),
    phone: form.phone.value.trim(),
    address: form.address.value.trim(),
    note: (form.note?.value || "").trim(),
    items: cart,
    total: cart.reduce((sum, i) => sum + Number(i.price) * Number(i.qty), 0)
  };

  const res = await fetch("/checkout", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data)
  });

  const result = await res.json();
  if (result.success) {
    alert("Đã gửi đơn hàng. Shop sẽ liên hệ lại với bạn.");

    // Copy nội dung đơn vào console
    let msg = "Đơn hàng của tôi:\n";
    cart.forEach(i => { msg += `- ${i.name} (x${i.qty}) - ${formatVND(i.price)}\n`; });
    msg += `Tổng: ${formatVND(data.total)}\nTên: ${data.name}\nSĐT: ${data.phone}`;
    console.log("Copy để dán sang Facebook/Zalo:\n" + msg);

    clearCart();
    renderCart();
    form.reset();
  } else {
    alert("Có lỗi khi gửi đơn. Bạn vui lòng liên hệ trực tiếp Facebook/Zalo giúp.");
  }
}

// Init
renderCart();
updateCartBadge();
