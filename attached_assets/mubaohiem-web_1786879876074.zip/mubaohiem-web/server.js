const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const session = require("express-session");
const bcrypt = require("bcrypt");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const nodemailer = require("nodemailer");

// Load .env (nếu không có dotenv vẫn chạy)
try { require("dotenv").config(); } catch (_) {}

const app = express();
const PORT = process.env.PORT || 3000;

/* ===================== MIDDLEWARE ===================== */
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// FIX: static tuyệt đối để không mất logo/banner khi chạy sai cwd
app.use(express.static(path.join(__dirname, "public")));

app.use(
  session({
    secret: process.env.SESSION_SECRET || "dev_secret_change_me",
    resave: false,
    saveUninitialized: false,
  })
);

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

app.use((req, res, next) => {
  res.locals.isAdmin = !!req.session.admin;
  next();
});


/* ===================== DATABASE ===================== */
// FIX QUAN TRỌNG: dùng DB đúng (trong zip của bạn dữ liệu nằm ở db/helmet.db)
const dbPath = path.join(__dirname, "db", "helmet.db");
const db = new sqlite3.Database(dbPath);

function columnExists(tableName, colName, cb) {
  db.all(`PRAGMA table_info(${tableName})`, (err, rows) => {
    if (err) return cb(false);
    cb(rows.some((r) => r.name === colName));
  });
}

function ensureColumn(tableName, colName, sqlType) {
  columnExists(tableName, colName, (exists) => {
    if (exists) return;
    db.run(`ALTER TABLE ${tableName} ADD COLUMN ${colName} ${sqlType}`, (err) => {
      if (err) console.log("Migration warn:", err.message);
      else console.log(`✔ Migrated: added ${tableName}.${colName}`);
    });
  });
}


db.serialize(() => {
  // USERS
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE,
      password TEXT
    )
  `);

  // PRODUCTS (zip của bạn đã có bảng products trong helmet.db)
  // đảm bảo các cột cần thiết tồn tại
  ensureColumn("products", "slug", "TEXT");
  ensureColumn("products", "images", "TEXT");
  ensureColumn("products", "thumbnail", "TEXT");
  ensureColumn("products", "content", "TEXT");
  ensureColumn("products", "category", "TEXT");
  ensureColumn("products", "price", "INTEGER");

  // ORDERS
  db.run(`
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_name TEXT,
      phone TEXT,
      address TEXT,
      note TEXT,
      total INTEGER,
      status TEXT DEFAULT 'new',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id INTEGER,
      product_id INTEGER,
      name TEXT,
      price INTEGER,
      quantity INTEGER
    )
  `);
});

/* ===================== ADMIN DEFAULT ===================== */
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASS = process.env.ADMIN_PASS || "123456";


db.get("SELECT * FROM users WHERE username = ?", [ADMIN_USER], async (err, row) => {
  if (err) return console.log("DB error:", err.message);
  if (!row) {
    const hash = await bcrypt.hash(ADMIN_PASS, 10);
    db.run("INSERT INTO users (username, password) VALUES (?,?)", [ADMIN_USER, hash]);
    console.log("✔ Admin user created:", ADMIN_USER);
  }
});

/* ===================== MULTER UPLOAD ===================== */
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const dir = path.join(__dirname, "public", "uploads");
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => {
    const safe = file.originalname.replace(/\s+/g, "-");
    cb(null, Date.now() + "-" + safe);
  },
});
const upload = multer({ storage });

/* ===================== EMAIL (OPTIONAL) ===================== */
let transporter = null;
if (process.env.MAIL_ENABLED === "true") {
  transporter = nodemailer.createTransport({
    service: "gmail",
    auth: { user: process.env.MAIL_USER, pass: process.env.MAIL_PASS },
  });
}

/* ===================== SLUG HELPERS ===================== */
function slugify(input) {
  return String(input || "")
    .toLowerCase()
    .trim()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "");
}

function generateUniqueSlug(name, excludeId, cb) {
  const base = slugify(name) || "san-pham";
  let candidate = base;
  let n = 2;

  const check = () => {
    const sql = excludeId
      ? "SELECT id FROM products WHERE slug = ? AND id != ? LIMIT 1"
      : "SELECT id FROM products WHERE slug = ? LIMIT 1";
    const params = excludeId ? [candidate, excludeId] : [candidate];

    db.get(sql, params, (err, row) => {
      if (err) return cb(base);
      if (!row) return cb(candidate);
      candidate = `${base}-${n++}`;
      check();
    });
  };

  check();
}

function getUserColumns(cb) {
  db.all("PRAGMA table_info(users)", (err, rows) => {
    if (err) return cb([]);
    cb(rows.map(r => r.name));
  });
}

function resolveUserSchema(cb) {
  getUserColumns((cols) => {
    // tìm cột username
    const usernameCol =
      cols.includes("username") ? "username" :
      cols.includes("user") ? "user" :
      cols.includes("email") ? "email" :
      cols.includes("name") ? "name" :
      null;

    // tìm cột password
    const passwordCol =
      cols.includes("password") ? "password" :
      cols.includes("pass") ? "pass" :
      cols.includes("matkhau") ? "matkhau" :
      cols.includes("pwd") ? "pwd" :
      cols.includes("hash") ? "hash" :
      null;

    cb({ cols, usernameCol, passwordCol });
  });
}


/* ===================== AUTH GUARD ===================== */
function requireAdmin(req, res, next) {
  if (!req.session.admin) return res.redirect("/admin");
  next();
}



/* ===================== SHOP ROUTES ===================== */
app.get("/", (req, res) => {
  const q = (req.query.q || "").trim();
  const category = (req.query.category || "").trim();

  let sql = "SELECT * FROM products";
  const where = [];
  const params = [];

  if (q) {
    where.push("(name LIKE ? OR content LIKE ? OR category LIKE ?)");
    params.push(`%${q}%`, `%${q}%`, `%${q}%`);
  }

  if (category) {
    where.push("category LIKE ?");
    params.push(`%${category}%`);
  }

  if (where.length) sql += " WHERE " + where.join(" AND ");
  sql += " ORDER BY id DESC";

  db.all(sql, params, (err, products) => {
    if (err) return res.status(500).send("DB error");
    res.render("index", { products, q, category });
  });
});


// Fallback theo id: nếu chưa có slug thì tạo -> redirect
app.get("/product/:id", (req, res) => {
  const id = Number(req.params.id);
  db.get("SELECT * FROM products WHERE id = ? LIMIT 1", [id], (err, p) => {
    if (err) return res.status(500).send("DB error");
    if (!p) return res.status(404).send("Không tìm thấy sản phẩm");

    if (!p.slug) {
      generateUniqueSlug(p.name, p.id, (newSlug) => {
        db.run("UPDATE products SET slug = ? WHERE id = ?", [newSlug, p.id], () => {
          res.redirect(`/p/${newSlug}`);
        });
      });
      return;
    }
    res.redirect(`/p/${p.slug}`);
  });
});

/* ===================== CHECKOUT ===================== */
app.post("/checkout", (req, res) => {
  // hỗ trợ cả 2 kiểu payload:
  // - items: array (cart.js của bạn thường gửi kiểu này)
  // - cart: JSON string (fallback)
  const { name, phone, address, note, items, cart, total } = req.body;

  let list = [];
  if (Array.isArray(items)) {
    list = items;
  } else {
    try {
      const parsed = JSON.parse(cart || "[]");
      list = Array.isArray(parsed) ? parsed : [];
    } catch { list = []; }
  }

  db.run(
    `INSERT INTO orders (customer_name, phone, address, note, total)
     VALUES (?,?,?,?,?)`,
    [name || "", phone || "", address || "", note || "", Number(total || 0)],
    function () {
      const orderId = this.lastID;

      const stmt = db.prepare(`
        INSERT INTO order_items (order_id, product_id, name, price, quantity)
        VALUES (?,?,?,?,?)
      `);

      list.forEach((it) => {
        stmt.run(
          orderId,
          Number(it.id || 0),
          String(it.name || ""),
          Number(it.price || 0),
          Number(it.qty || it.quantity || 1)
        );
      });

      stmt.finalize();

      if (transporter && process.env.MAIL_TO) {
        transporter.sendMail({
          from: process.env.MAIL_USER,
          to: process.env.MAIL_TO,
          subject: "Đơn hàng mới - Đồ phượt Quảng Trị",
          html: `
            <h3>Đơn hàng #${orderId}</h3>
            <p><b>Khách:</b> ${name || ""}</p>
            <p><b>SĐT:</b> ${phone || ""}</p>
            <p><b>Địa chỉ:</b> ${address || ""}</p>
            <p><b>Ghi chú:</b> ${note || ""}</p>
            <p><b>Tổng:</b> ${Number(total || 0).toLocaleString("vi-VN")} đ</p>
          `,
        }).catch(e => console.log("Mail error:", e.message));
      }

      return res.json({ success: true, orderId });
    }
  );
});

/* ===================== ADMIN ===================== */
// FIX: link cũ từ index.ejs đang trỏ /admin/login
app.get("/admin/login", (req, res) => res.redirect("/admin"));

app.get("/admin", (req, res) => {
  res.render("admin/login", { error: null });
});

app.post("/admin/login", (req, res) => {
  const { username, password } = req.body;

  db.get(
    "SELECT * FROM users WHERE username = ?",
    [username],
    async (err, user) => {
      if (err) {
        console.log("DB error:", err.message);
        return res.render("admin/login", { error: "Lỗi hệ thống" });
      }

      if (!user) {
        return res.render("admin/login", { error: "Sai tài khoản hoặc mật khẩu" });
      }

      try {
        const ok = await bcrypt.compare(password, user.password_hash);

        if (!ok) {
          return res.render("admin/login", { error: "Sai tài khoản hoặc mật khẩu" });
        }

        req.session.admin = true;
        return res.redirect("/admin/products");
      } catch (e) {
        console.log("bcrypt error:", e.message);
        return res.render("admin/login", { error: "Lỗi xử lý đăng nhập" });
      }
    }
  );
});


app.get("/admin/logout", (req, res) => {
  req.session.destroy(() => res.redirect("/admin"));
});

app.get("/admin/products", requireAdmin, (req, res) => {
  db.all("SELECT * FROM products ORDER BY id DESC", (err, products) => {
    if (err) return res.status(500).send("DB error");
    res.render("admin/dashboard", { products });
  });
});

app.get("/admin/products/new", requireAdmin, (req, res) => {
  res.render("admin/product-form", { product: null });
});

app.get("/cart", (req, res) => {
  res.render("cart");
});


// CREATE
app.post("/admin/products/new", requireAdmin, upload.array("images", 12), (req, res) => {
  const { name, price, category, content, thumbnail } = req.body;

  const files = req.files || [];
  const urls = files.map((f) => "/uploads/" + f.filename);

  const thumbIndex = Number(thumbnail || 0);
  const thumbUrl = urls[thumbIndex] || urls[0] || "";
  const imagesJson = JSON.stringify(urls);

  generateUniqueSlug(name, null, (slug) => {
    db.run(
      `INSERT INTO products (name, slug, price, category, thumbnail, content, images)
       VALUES (?,?,?,?,?,?,?)`,
      [
        name || "",
        slug,
        Number(price || 0),
        category || "",
        thumbUrl,
        (content || "").toString(),
        imagesJson,
      ],
      (err2) => {
        if (err2) {
          console.log("Create product error:", err2.message);
          return res.status(500).send("Lỗi tạo sản phẩm");
        }
        res.redirect("/admin/products");
      }
    );
  });
});

// EDIT FORM
app.get("/admin/products/:id/edit", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  db.get("SELECT * FROM products WHERE id = ? LIMIT 1", [id], (err, product) => {
    if (err) return res.status(500).send("DB error");
    if (!product) return res.status(404).send("Không tìm thấy sản phẩm");
    res.render("admin/product-form", { product });
  });
});

// UPDATE
app.post("/admin/products/:id/edit", requireAdmin, upload.array("images", 12), (req, res) => {
  const id = Number(req.params.id);
  const { name, price, category, content, thumbnail } = req.body;

  db.get("SELECT * FROM products WHERE id = ? LIMIT 1", [id], (err, old) => {
    if (err) return res.status(500).send("DB error");
    if (!old) return res.status(404).send("Không tìm thấy sản phẩm");

    const files = req.files || [];
    const newUrls = files.map((f) => "/uploads/" + f.filename);

    let oldUrls = [];
    try {
      const arr = JSON.parse(old.images || "[]");
      oldUrls = Array.isArray(arr) ? arr : [];
    } catch { oldUrls = []; }

    const finalUrls = newUrls.length ? newUrls : oldUrls;
    const imagesJson = JSON.stringify(finalUrls);

    const thumbIndex = Number(thumbnail || 0);
    const finalThumb = newUrls.length
      ? (finalUrls[thumbIndex] || finalUrls[0] || "")
      : (old.thumbnail || finalUrls[0] || "");

    generateUniqueSlug(name, id, (slug) => {
      db.run(
        `UPDATE products
         SET name=?, slug=?, price=?, category=?, thumbnail=?, content=?, images=?
         WHERE id=?`,
        [
          name || "",
          slug,
          Number(price || 0),
          category || "",
          finalThumb,
          (content || "").toString(),
          imagesJson,
          id,
        ],
        (err2) => {
          if (err2) {
            console.log("Update product error:", err2.message);
            return res.status(500).send("Lỗi cập nhật sản phẩm");
          }
          res.redirect("/admin/products");
        }
      );
    });
  });
});

// DELETE
app.post("/admin/products/:id/delete", requireAdmin, (req, res) => {
  const id = Number(req.params.id);
  db.run("DELETE FROM products WHERE id = ?", [id], (err) => {
    if (err) return res.status(500).send("Lỗi xóa sản phẩm");
    res.redirect("/admin/products");
  });
});

/* ===================== START ===================== */
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
  console.log(`🗄️ Using DB: ${dbPath}`);
});
